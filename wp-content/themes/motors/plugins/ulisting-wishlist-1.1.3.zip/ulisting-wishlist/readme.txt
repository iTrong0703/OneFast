=== uListing Wishlist ===
Contributors: Stylemix
Donate link: https://stylemixthemes.com
Tags: listing
Requires at least: 4.6
Tested up to: 5.7
Stable tag: 1.1.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

uListing Wishlist WordPress plugin

== Installation ==
This section describes how to install the plugin and get it working.

1. Upload the plugin files to the `/wp-content/plugins/` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Please find more details on Plugin Installation in documentation
4. Set Up Page in Menu -> Listings.

== Changelog ==

= 1.1.3 =
* Compatibility update with uListing 2.0.0

= 1.1.2 =
* Saved Search not working bug fixed

= 1.1.1 =
* "stm_render()" function renamed to "ulisting_render_template()"

= 1.1.0 =
* Support page integrated.
* Fatal Error without uListing plugin fixed

= 1.0.9 =
* Update Freemius SDK.

= 1.0.8 =
* Minor bug fixes.

= 1.0.7 =
* Minor bug fixes.

= 1.0.6 =
* Minor bug fixes.

= 1.0.5 =
* Minor bug fixes.

= 1.0.4 =
* Minor bug fixes.

= 1.0.3 =
* Added: Saved Searches & Email Alerts
* Minor bug fixes.

= 1.0.2 =
* Minor bug fixes.

= 1.0.1 =
* Minor bug fixes.