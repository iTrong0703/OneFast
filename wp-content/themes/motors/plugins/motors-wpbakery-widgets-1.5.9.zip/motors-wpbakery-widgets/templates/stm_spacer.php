<?php
echo '<div class="stm-vc-spacer"></div>';
