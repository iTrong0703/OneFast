<?php
do_action( 'stm_listings_load_template', 'trade-in' );
