<?php
$price                = get_post_meta( get_the_ID(), 'price', true );
$sale_price           = get_post_meta( get_the_ID(), 'sale_price', true );
$car_price_form_label = get_post_meta( get_the_ID(), 'car_price_form_label', true );

$regular_price_label = get_post_meta( get_the_ID(), 'regular_price_label', true );
$special_price_label = get_post_meta( get_the_ID(), 'special_price_label', true );

$rentPrice     = get_post_meta( get_the_ID(), 'rent_price', true );
$saleRentPrice = get_post_meta( get_the_ID(), 'sale_rent_price', true );

$body        = get_post_meta( get_the_ID(), 'body', true );
$listingType = get_post_meta( get_the_ID(), 'listing-type', true );

$archive_link = apply_filters( 'stm_filter_listing_link', '' );

$terms = array();
if ( $body ) {
	foreach ( explode( ',', $body ) as $k => $b ) {
		$bodyName = get_term_by( 'slug', $b, 'body' );
		$terms[]  = '<a href="' . $archive_link . '?body=' . $bodyName->slug . '">' . $bodyName->name . '</a>';
	}
}

if ( $listingType ) {
	foreach ( explode( ',', $listingType ) as $k => $type ) {
		$lt = get_term_by( 'slug', $type, 'listing-type' );
		if ( $lt ) {
			$terms[] = '<a href="' . $archive_link . '?listing-type=' . $lt->slug . '">' . $lt->name . '</a>';
		}
	}
}

?>

<div class="stm-listing-single-price-title heading-font clearfix">
	<div class="listing-title-wrap">
		<div class="terms-wrap">
			<?php echo ( ! empty( $terms ) ) ? wp_kses_post( implode( ' | ', $terms ) ) : ''; ?>
		</div>
		<h1 class="title">
			<?php echo wp_kses_post( apply_filters( 'stm_generate_title_from_slugs', get_the_title( get_the_ID() ), get_the_ID(), true ) ); ?>
		</h1>
	</div>
	<div class="price-wrap">
		<?php if ( ! empty( $rentPrice ) || ! empty( $saleRentPrice ) ) { ?>
			<div class="rent-price-wrap">
				<div class="label normal_font"><?php echo ( empty( $saleRentPrice ) ) ? esc_html__( 'Rent Prices', 'stm_motors_equipment' ) : sprintf( esc_html__( '%s/Day', 'stm_motors_equipment' ), apply_filters( 'stm_filter_price_view', '', $saleRentPrice ) ); //phpcs:ignore ?></div>
				<div class="price heading-font"><?php echo sprintf( __( '<span>%s</span>/Day', 'stm_motors_equipment' ), ( ! empty( $rentPrice ) && empty( $saleRentPrice ) ) ? apply_filters( 'stm_filter_price_view', '', $rentPrice ) : apply_filters( 'stm_filter_price_view', '', $saleRentPrice ) ); //phpcs:ignore ?></div>
			</div>
		<?php } ?>

		<?php if ( ! empty( $car_price_form_label ) ) : ?>
			<div class="price_unit">
				<div class="price">
					<div class="stm_custom_label normal_font">
						<?php echo esc_attr( $car_price_form_label ); ?>
					</div>
				</div>
			</div>
		<?php else : ?>
			<div class="price_unit">
				<?php if ( ! empty( $sale_price ) ) : ?>
					<div class="price">
						<div class="inner heading-font">
							<?php if ( ! empty( $special_price_label ) ) : ?>
								<div class="stm_label normal_font"><?php echo esc_html( $special_price_label ); ?></div>
							<?php else : ?>
								<div class="stm_label normal_font"><?php echo ( empty( $sale_price ) ) ? esc_html__( 'Price', 'stm_motors_equipment' ) : apply_filters( 'stm_filter_price_view', '', $price ); //phpcs:ignore ?></div>
							<?php endif; ?>
							<?php echo ( empty( $sale_price ) ) ? apply_filters( 'stm_filter_price_view', '', $price ) : apply_filters( 'stm_filter_price_view', '', $sale_price );  //phpcs:ignore ?>
						</div>
					</div>
				<?php elseif ( ! empty( $price ) ) : ?>
					<div class="price">
						<div class="inner heading-font">
							<div class="stm_label normal_font"><?php echo ( ! empty( $regular_price_label ) ) ? esc_html( $regular_price_label ) : esc_html__( 'Sale Price', 'stm_motors_equipment' ); //phpcs:ignore ?></div>
							<?php echo apply_filters( 'stm_filter_price_view', '', $price ); //phpcs:ignore ?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		<?php endif; ?>
	</div>
</div>
