<?php

if ( ! function_exists( 'stm_equipment_module_enqueue_scripts_styles' ) ) {
	function stm_equipment_module_enqueue_scripts_styles( $fileName ) {
		if ( 'site_style_default' === apply_filters( 'stm_me_get_nuxy_mod', 'site_style_default', 'site_style' ) ) {
			if ( file_exists( STM_MOTORS_EQUIPMENT_PATH . '/assets/css/vc_ss/' . $fileName . '.css' ) ) {
				wp_enqueue_style( $fileName, STM_MOTORS_EQUIPMENT_URL . '/assets/css/vc_ss/' . $fileName . '.css', null, STM_MOTORS_EQUIPMENT_SS_V, 'all' );
			}
		}

		if ( file_exists( STM_MOTORS_EQUIPMENT_PATH . '/assets/js/vc_ss/' . $fileName . '.js' ) ) {
			wp_enqueue_script( $fileName, STM_MOTORS_EQUIPMENT_URL . '/assets/js/vc_ss/' . $fileName . '.js', 'jquery', STM_MOTORS_EQUIPMENT_SS_V, true );
		}
	}
}
