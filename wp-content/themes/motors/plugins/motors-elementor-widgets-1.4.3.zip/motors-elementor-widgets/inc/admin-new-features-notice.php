<?php
if ( MOTORS_ELEMENTOR_WIDGETS_PLUGIN_VERSION < '1.2.15' && defined( 'STM_ADMIN_NOTICES_VERSION' ) && function_exists( 'stm_admin_notices_init' ) && empty( get_option( 'features_settings_clicked' ) ) ) {

	wp_enqueue_script( 'admin-features-notices', MOTORS_ELEMENTOR_WIDGETS_URL . '/assets/js/admin/new-features-notice.js', array( 'jquery' ), MOTORS_ELEMENTOR_WIDGETS_PLUGIN_VERSION, true );

	$init_data = array(
		'notice_type'          => 'animate-triangle-notice only-title has-btn',
		'notice_logo'          => 'attent_triangle.svg',
		'notice_title'         => 'Important: Features can be now set up in the Theme Options. Please, check your current Features to ensure they work correctly.',
		'notice_btn_one'       => admin_url( 'admin.php?page=wpcfto_motors_' . get_option( 'stm_motors_chosen_template', 'car_dealer' ) . '_settings#features_settings' ),
		'notice_btn_one_title' => 'Features Settings',
		'notice_btn_one_class' => 'close-after-click',
	);

	stm_admin_notices_init( $init_data );
}
