<div>
	<?php get_template_part( 'partials/rental/product/info' ); ?>
</div>
