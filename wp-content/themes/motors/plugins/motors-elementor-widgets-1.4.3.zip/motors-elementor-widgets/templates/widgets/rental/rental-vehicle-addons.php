<div class="rental-reservation-addons">
	<?php get_template_part( 'partials/rental/product/options', 'archive' ); ?>
</div>
