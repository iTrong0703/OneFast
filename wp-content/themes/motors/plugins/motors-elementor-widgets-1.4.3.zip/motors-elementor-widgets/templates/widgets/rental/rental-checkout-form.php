<div class="stm_custom_rental_checkout">
	<?php echo do_shortcode( '[woocommerce_checkout]' ); ?>
</div>
