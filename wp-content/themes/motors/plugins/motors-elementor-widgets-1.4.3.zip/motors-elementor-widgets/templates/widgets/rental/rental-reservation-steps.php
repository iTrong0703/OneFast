<div>
	<?php get_template_part( 'partials/rental/wizard' ); ?>
	<?php get_template_part( 'partials/rental/wizard', 'bg' ); ?>
</div>
