<div class="stm-info-block-animate">
	<div class="info-wrap">
		<span>
			<div class="stm_flipbox">
				<div class="stm_flipbox__front">
					<div class="inner">
						<div class="inner-flex">
							<?php if ( ! empty( $flipbox_icon ) ) : ?>
								<div class="stm_iconbox__icon">
									<?php echo wp_kses( $flipbox_icon, apply_filters( 'stm_ew_kses_svg', array() ) ); ?>
								</div>
							<?php endif; ?>
							<?php if ( ! empty( $flipbox_image ) && is_array( $flipbox_image ) && isset( $flipbox_image['url'] ) ) : ?>
								<div class="stm_iconbox__img">
									<img src="<?php echo esc_url( $flipbox_image['url'] ); ?>" alt="" />
								</div>
							<?php endif; ?>
							<div class="ib-title heading-font"><?php echo esc_html( $flipbox_title ); ?></div>
						</div>
					</div>
				</div>
				<div class="stm_flipbox__back">
					<div class="inner mbc">
						<div class="inner-flex">
							<div class="ib-title"><?php echo esc_html( $flipbox_title ); ?></div>
							<div class="ib-desc"><?php echo esc_html( $flipbox_description ); ?></div>
						</div>
					</div>
				</div>
			</div>
		</span>
	</div>
</div>
