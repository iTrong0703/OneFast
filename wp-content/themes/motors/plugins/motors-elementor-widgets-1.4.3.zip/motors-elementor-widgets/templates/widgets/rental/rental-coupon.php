<div class="rental-coupon">
	<?php get_template_part( 'partials/rental/common/coupon', 'form' ); ?>
</div>
