<div class="col-md-4 col-sm-12">
	<div class="stm_price_input">
		<div
			class="stm_label heading-font"><?php esc_html_e( 'Custom label instead of price', 'motors-elementor-widgets' ); ?></div>
		<input type="text" class="heading-font" name="car_price_form_label" value="<?php echo esc_attr( $car_price_form_label ); ?>"/>
	</div>
</div>
