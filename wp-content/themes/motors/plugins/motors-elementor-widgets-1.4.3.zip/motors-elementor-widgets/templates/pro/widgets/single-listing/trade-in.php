<div class="stm-car_dealer-buttons heading-font">
	<a href="#trade-in" data-toggle="modal" data-target="#trade-in">
		<span class="label"><?php echo esc_html( $tif_btn_label ); ?></span>
		<i class="stm-moto-icon-trade"></i>
	</a>
</div>
