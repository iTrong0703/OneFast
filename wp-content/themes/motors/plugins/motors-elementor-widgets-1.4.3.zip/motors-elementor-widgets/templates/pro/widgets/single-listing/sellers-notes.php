<?php
global $listing_id;

$listing_id = ( is_null( $listing_id ) ) ? get_the_ID() : $listing_id;
?>
<div class="post-content sellers-notes">
	<?php echo wp_kses_post( apply_filters( 'stm_get_listing_seller_note', $listing_id ) ); ?>
</div>

