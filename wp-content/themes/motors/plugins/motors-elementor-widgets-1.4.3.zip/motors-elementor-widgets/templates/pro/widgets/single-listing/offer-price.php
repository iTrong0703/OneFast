<div class="stm-car_dealer-buttons heading-font">
	<a href="#trade-offer" data-toggle="modal" data-target="#trade-offer">
		<span class="label"><?php echo esc_html( $opb_btn_label ); ?></span>
		<i class="stm-moto-icon-cash"></i>
	</a>
</div>
