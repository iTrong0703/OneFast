<?php

/**
 * Depricated from 3.0 version.
 *
 * @deprecated 3.0
 */

if ( ! class_exists( 'STM_LMS_Settings' ) ) {
	class STM_LMS_Settings {
		public static function stm_get_post_type_array() {
		}
	}
}
