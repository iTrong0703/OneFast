<?php
//phpcs:disable
$bgColor            = apply_filters( 'stm_me_get_nuxy_mod', '', 'top_bar_bg_color' );
$top_bar_address    = apply_filters( 'stm_me_get_nuxy_mod', '', 'top_bar_address' );
$header_address_url = apply_filters( 'stm_me_get_nuxy_mod', '', 'header_address_url' );
?>

<div class="top-bar-wrap">
	<div class="container">
		<div class="stm-c-six-top-bar">
			<?php stm_c_six_load_template( 'header/parts/lang-switcher' ); ?>
			<?php if ( ! empty( $top_bar_address ) ) : ?>
				<div class="stm-top-address-wrap">
                    <span id="top-bar-address" class="<?php if ( ! empty( $header_address_url ) ) {
						echo 'fancy-iframe';
					} ?>" data-iframe="true" data-src="<?php echo esc_url( $header_address_url ); ?>">
                        <i class="fas fa-map-marker"></i> <?php echo esc_html( apply_filters( 'stm_dynamic_string_translation', $top_bar_address, 'Top Bar Address' ) ); ?>
                    </span>
				</div>
			<?php endif; ?>
			<div class="pull-right">
				<?php stm_c_six_load_template( 'header/parts/socials' ); ?>
				<?php if ( ! is_user_logged_in() ) {
					stm_c_six_load_template( 'header/parts/login-reg-links' );
				} ?>
			</div>
		</div>
	</div>
</div>
<?php //phpcs:enable
