<div id='picker-preview-container'>
	<p> <?php esc_html_e( 'Define the color schema available in the WPBakery color picker as color presets. Add your brand or frequently used colors for quick access. These settings affect only the color picker and will not affect any theme settings. ' ) ?></p>
	<div id='preview-picker'></div>
</div>
