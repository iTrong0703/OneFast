/**
 * RightPress Settings Scripts
 */

jQuery(document).ready(function() {

    'use strict';

    // TODO: Add something or remove file

});
