<?php
function register_car_rental_info_metabox( $manager ) {
	/*Register sections*/
	$manager->register_section(
		'stm_car_rent_info',
		array(
			'label' => esc_html__( 'Car Details', 'stm_motors_car_rental' ),
			'icon'  => 'fa fa-bookmark',
		)
	);

	/*Register controls*/
	$fields = array(
		'cars_qty'      => array(
			'type'  => 'text',
			'label' => esc_html__( 'Stock quantity', 'stm_motors_car_rental' ),
		),
		'cars_info'     => array(
			'type'  => 'text',
			'label' => esc_html__( 'Cars included', 'stm_motors_car_rental' ),
		),
		'min_rent_days' => array(
			'type'        => 'number',
			'label'       => esc_html__( 'Minimum rent days', 'stm_motors_car_rental' ),
			'description' => esc_html__( 'Enter number of minimum days for rent', 'stm_motors_car_rental' ),
			'attr'        => array( 'class' => 'widefat' ),
		),
		'max_rent_days' => array(
			'type'        => 'number',
			'label'       => esc_html__( 'Maximum rent days', 'stm_motors_car_rental' ),
			'description' => esc_html__( 'Enter number of maximum days for rent', 'stm_motors_car_rental' ),
			'attr'        => array( 'class' => 'widefat' ),
		),
	);

	if ( function_exists( 'stm_rental_locations' ) ) {
		$locations = stm_rental_locations( true );

		if ( count( $locations ) > 0 ) {
			$officesArray = array();
			/*Add multiselects*/
			foreach ( $locations as $key => $option ) {
				$officesArray[ stm_get_wpml_office_parent_id( $option[5] ) ] = $option[4];
			}

			$fields['stm_rental_office'] = array(
				'type'     => 'multiselect',
				'label'    => esc_html__( 'Offices', 'stm_motors_car_rental' ),
				'choices'  => $officesArray,
				'validate' => 'stm_motors_car_rental_multiselect',
			);
		}
	}

	$fields = apply_filters( 'stm_projects_fields', $fields );

	foreach ( $fields as $field => $field_info ) {
		/*Register control*/
		$type     = ( ! empty( $field_info['type'] ) ) ? $field_info['type'] : 'text';
		$validate = ( ! empty( $field_info['validate'] ) ) ? $field_info['validate'] : 'stm_motors_car_rental_no_validate';

		$atts = array(
			'type'    => $type,
			'section' => 'stm_car_rent_info',
			'label'   => $field_info['label'],
			'attr'    => array(
				'class' => 'widefat',
			),
		);

		if ( isset( $field_info['choices'] ) ) {
			$atts = array(
				'type'    => $type,
				'section' => 'stm_car_rent_info',
				'label'   => $field_info['label'],
				'choices' => $field_info['choices'],
			);
		}

		$manager->register_control(
			$field,
			$atts
		);

		/*Register setting*/
		$manager->register_setting(
			$field,
			array(
				'sanitize_callback' => $validate,
			)
		);
	}
}
