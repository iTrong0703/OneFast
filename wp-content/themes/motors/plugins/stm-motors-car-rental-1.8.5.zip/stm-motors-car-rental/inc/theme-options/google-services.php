<?php
add_filter(
	'motors_wpcfto_general_start_config',
	function ( $conf ) {

		$google_conf = array(
			'enable_recaptcha'     =>
				array(
					'label'       => esc_html__( 'reCaptcha (v3)', 'stm_motors_car_rental' ),
					'type'        => 'checkbox',
					'description' => 'Enable Google reCaptcha. To obtain the keys please visit: <a href="https://www.google.com/recaptcha/admin">here</a>',
					'group'       => 'started',
				),
			'recaptcha_public_key' =>
				array(
					'label'      => esc_html__( 'Public key', 'stm_motors_car_rental' ),
					'type'       => 'text',
					'dependency' => array(
						'key'   => 'enable_recaptcha',
						'value' => 'not_empty',
					),
				),
			'recaptcha_secret_key' =>
				array(
					'label'      => esc_html__( 'Secret key', 'stm_motors_car_rental' ),
					'type'       => 'text',
					'group'      => 'ended',
					'dependency' => array(
						'key'   => 'enable_recaptcha',
						'value' => 'not_empty',
					),
				),
		);

		$conf = array_merge( $conf, $google_conf );

		return $conf;
	},
	20,
	1
);
