<?php
global $product;
$stm_id = get_the_ID();

if ( is_product() ) {
	$product = new WC_Product( get_the_ID() );
}

if ( is_cart() ) {
	$cart_items = stm_get_cart_items();
	$stm_id     = $cart_items['car_class']['id'];
	$product    = new WC_Product( $stm_id );
}

$order_values = stm_get_rental_order_fields_values();
$order_days   = ( ! empty( $order_values['order_days'] ) ) ? $order_values['order_days'] : 0;

if ( empty( $product ) ) {
	return;
}

$has_gallery        = ( ! empty( $product->get_gallery_image_ids() ) ) ? array_chunk( $product->get_gallery_image_ids(), 3 ) : array();
$product_attributes = stm_mcr_get_product_atts( $product );
$excerpt            = get_the_excerpt( $stm_id );
$current_car        = stm_get_cart_items();
$current_car_id     = 0;

if ( ! empty( $current_car['car_class'] ) ) {
	if ( ! empty( $current_car['car_class']['id'] ) ) {
		$current_car_id = $current_car['car_class']['id'];
	}
}

$current_car = '';
if ( $stm_id === $current_car_id ) {
	$current_car = 'current_car';
}

$args = array(
	'post_type'      => 'product',
	'post_status'    => 'publish',
	'posts_per_page' => '15',
	'tax_query'      => array(
		array(
			'taxonomy' => 'product_type',
			'field'    => 'slug',
			'terms'    => 'car_option',
		),
	),
);

$car_options_posts  = new WP_Query( $args );
$rent_allow_data    = apply_filters( 'get_max_min_days', $stm_id, $order_days );
$dates              = ( isset( $_COOKIE[ 'stm_calc_pickup_date_' . get_current_blog_id() ] ) ) ? stm_check_order_available( $stm_id, urldecode( sanitize_text_field( $_COOKIE[ 'stm_calc_pickup_date_' . get_current_blog_id() ] ) ), urldecode( sanitize_text_field( $_COOKIE[ 'stm_calc_return_date_' . get_current_blog_id() ] ) ) ) : array();
$disable_car        = count( $dates ) > 0 || ! $rent_allow_data['allow'] ? 'stm-disable-car' : '';
$already_booked     = count( $dates ) > 0 ? true : false;
$disable_button     = count( $dates ) > 0 || ! $rent_allow_data['allow'] ? 'stm-disable-pay-btn' : '';
$invisible_block_id = 'stm-invisible-' . wp_rand( 1, 99999 );
?>

<div class="col-md-6 col-sm-12">
	<div class="smt-cr-grid-loop-wrap stm-cr-reservation-page <?php echo esc_attr( $invisible_block_id ); ?> <?php echo esc_attr( $disable_car ); ?>"
		id="product-<?php echo esc_attr( $stm_id ); ?>">
		<div class="reserv-visible-block">
			<div class="reserv-car-info-wrap">
				<div class="car-info-top">
					<div class="car-preview-img">
						<?php if ( has_post_thumbnail() ) : ?>
							<div class="image">
								<?php the_post_thumbnail( 'stm-img-350-181', array( 'class' => 'img-responsive' ) ); ?>
							</div>
						<?php endif; ?>
					</div>
					<div class="car-data">
						<?php if ( isset( $product_attributes['attribute_pa_vehicle-class'] ) ) : ?>
							<div class="car-class-wrap">
								<div class="car-class">
									<?php echo wp_kses_post( $product_attributes['attribute_pa_vehicle-class']['value'] ); ?>
								</div>
							</div>
						<?php endif; ?>
						<h3><?php the_title(); ?></h3>
						<div class="stm-mcr-similat-text"><?php echo esc_html__( 'or similar', 'stm_motors_car_rental' ); ?></div>
					</div>
				</div>
				<div class="car-info-middle">
					<?php if ( ! empty( $disable_car ) ) : ?>
						<div class="stm-enable-car-date">
							<?php
							$formatted_dates = array();
							foreach ( $dates as $val ) {
								$formatted_dates[] = date_i18n( 'd M', strtotime( $val ) );
							}
							?>
							<?php if ( isset( $already_booked ) && true === $already_booked ) : ?>
							<h3>
								<?php echo esc_html__( 'This Class is already booked in: ', 'stm_motors_car_rental' ) . "<span class='yellow'>" . implode( '<span>,</span> ', $formatted_dates ) . '</span>'; //phpcs:ignore  ?>
							</h3>
							<?php else : ?>
								<h3>
									<h3><?php echo esc_html( $rent_allow_data['message'] ); ?><span class="yellow"><?php echo esc_html( $rent_allow_data['days'] ); ?></span></h3>
								</h3>
							<?php endif; ?>
						</div>
					<?php endif; ?>
				</div>
			</div>
			<div class="car-info-bottom">
				<ul>
					<?php
					$i = 0;
					foreach ( $product_attributes as $attr ) {
						if ( $attr['show'] && $i < 3 ) {
							?>
							<li>
								<div class="attr-img">
									<img src="<?php echo esc_url( $attr['img'] ); ?>"/>
								</div>
								<div class="attr-value">
									<?php echo wp_kses_post( apply_filters( 'stm_mcr_lmth', $attr['value'] ) ); ?>
								</div>
							</li>
							<?php
							$i++;
						}
					}
					?>
					<li class="view-all-specific" data-invis="<?php echo esc_attr( $invisible_block_id ); ?>"
						data-tab="<?php echo esc_attr( 'specific-' . $stm_id ); ?>">
						<i class="fas fa-chevron-right"></i>
						<span><?php echo esc_html__( 'View All Specifications', 'stm_motors_car_rental' ); ?></span>
					</li>
				</ul>
			</div>
			<div class="reserv-price-wrap">
				<?php
				stm_car_rental_load_template(
					'shop/parts/price-view',
					array(
						'is_add_to_cart' => false,
						'invis_id'       => $invisible_block_id,
						'disableBtns'    => $disable_button,
					)
				);
				?>
			</div>
		</div>
		<?php
		$extra_opt    = 'extra-opt-' . $stm_id;
		$terms        = 'terms-' . $stm_id;
		$specific     = 'specific-' . $stm_id;
		$gallery      = 'gallery-' . $stm_id;
		$stm_comments = 'comments-' . $stm_id;
		?>
		<div id="<?php echo esc_attr( $invisible_block_id ); ?>" class="reserv-invisible-block">
			<div class="tabs-wrapper">
				<ul class="nav nav-tabs owl-carousel" id="myTab<?php echo '-' . esc_attr( $stm_id ); ?>" role="tabreserv">
					<li class="nav-item active">
						<a class="nav-link" id="<?php echo esc_attr( $extra_opt ); ?>-tab" data-toggle="tab"
							href="#<?php echo esc_attr( $extra_opt ); ?>" role="tab"
							aria-controls="<?php echo esc_attr( $extra_opt ); ?>" aria-selected="true">
							<?php echo esc_html__( 'Extra Options', 'stm_motors_car_rental' ); ?>
						</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" id="<?php echo esc_attr( $terms ); ?>-tab" data-toggle="tab"
							href="#<?php echo esc_attr( $terms ); ?>" role="tab"
							aria-controls="<?php echo esc_attr( $terms ); ?>" aria-selected="false">
							<?php echo esc_html__( 'Rental Terms', 'stm_motors_car_rental' ); ?>
						</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" id="<?php echo esc_attr( $specific ); ?>-tab" data-toggle="tab"
							href="#<?php echo esc_attr( $specific ); ?>" role="tab"
							aria-controls="<?php echo esc_attr( $specific ); ?>" aria-selected="false">
							<?php echo esc_html__( 'All Specifications', 'stm_motors_car_rental' ); ?>
						</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" id="<?php echo esc_attr( $gallery ); ?>-tab" data-toggle="tab"
							href="#<?php echo esc_attr( $gallery ); ?>" role="tab"
							aria-controls="<?php echo esc_attr( $gallery ); ?>" aria-selected="false">
							<?php echo esc_html__( 'Image Gallery', 'stm_motors_car_rental' ); ?>
						</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" id="<?php echo esc_attr( $stm_comments ); ?>-tab" data-toggle="tab"
							href="#<?php echo esc_attr( $stm_comments ); ?>" role="tab"
							aria-controls="<?php echo esc_attr( $stm_comments ); ?>" aria-selected="false">
							<?php echo esc_html__( 'Comments', 'stm_motors_car_rental' ); ?>
						</a>
					</li>
				</ul>
				<div class="tab-content" id="myTabContent">
					<div class="tab-pane fade active in" id="<?php echo esc_attr( $extra_opt ); ?>" role="tabpanel"
						aria-labelledby="<?php echo esc_attr( $extra_opt ); ?>-tab">
						<?php
						stm_car_rental_load_template(
							'shop/tabs/car-options',
							array(
								'invisId'     => $invisible_block_id,
								'query_posts' => $car_options_posts,
							)
						);
						?>
					</div>
					<div class="tab-pane fade" id="<?php echo esc_attr( $terms ); ?>" role="tabpanel"
						aria-labelledby="<?php echo esc_attr( $terms ); ?>-tab">
						<?php
						$excerpt = get_the_excerpt( $stm_id );
						echo wp_kses_post( apply_filters( 'the_content', $excerpt ) );
						?>
					</div>
					<div class="tab-pane fade" id="<?php echo esc_attr( $specific ); ?>" role="tabpanel"
						aria-labelledby="<?php echo esc_attr( $specific ); ?>-tab">
						<?php stm_car_rental_load_template( 'shop/tabs/specifications', $product_attributes ); ?>
					</div>
					<div class="tab-pane fade" id="<?php echo esc_attr( $gallery ); ?>" role="tabpanel"
						aria-labelledby="<?php echo esc_attr( $gallery ); ?>-tab">
						<?php
						if ( $has_gallery ) {
							stm_car_rental_load_template( 'shop/tabs/gallery', $has_gallery );
						} else {
							echo '<h3>' . esc_html__( 'No Images', 'stm_motors_car_rental' ) . '</h3>';
						}
						?>
					</div>
					<div class="tab-pane fade" id="<?php echo esc_attr( $stm_comments ); ?>" role="tabpanel"
						aria-labelledby="<?php echo esc_attr( $stm_comments ); ?>-tab">
						<?php
						if ( function_exists( 'wc_get_template_part' ) ) {
							wc_get_template_part( 'single-product-reviews' );
						}
						?>
					</div>
				</div>
			</div>
			<div class="add-to-cart-btns">
				<?php
				stm_car_rental_load_template(
					'shop/parts/price-view',
					array(
						'is_add_to_cart' => true,
						'disableBtns'    => $disable_button,
					)
				);
				?>
			</div>
		</div>
	</div>
</div>
<script>
	(function($) {
		$(document).ready(function() {
			$('.nav-tabs').owlCarousel({
				items: 2,
				dots: false,
				center: false,
				autoWidth: true,
				touchDrag: false,
				mouseDrag: false,
			});
		});

		$('.nav-link').on('click', function() {
			$('.nav-tabs').find('.nav-item').removeClass('active');
		});
	})(jQuery)
</script>
