<?php
/**
 * Created by PhpStorm.
 * User: dima
 * Date: 10/22/19
 * Time: 14:54
 */

echo 123;