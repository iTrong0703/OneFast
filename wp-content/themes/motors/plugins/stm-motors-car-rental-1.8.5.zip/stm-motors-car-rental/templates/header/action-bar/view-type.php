<?php
$grid = '';
$list = 'active';

if ( ! empty( $_GET['view-type'] ) && 'grid' === $_GET['view-type'] ) { //phpcs:ignore
	$list = '';
	$grid = 'active';
}

$reservId = apply_filters( 'stm_me_get_nuxy_mod', '', 'rental_datepick' );
?>
<div class="view-type">
	<ul>
		<li>
			<a href="<?php echo esc_url( get_the_permalink( $reservId ) ); ?>?view-type=grid"
			class="<?php echo esc_attr( $grid ); ?>">
				<i class="stm-carent-rental-ico-grid"></i>
			</a>
		</li>
		<li>
			<a href="<?php echo esc_url( get_the_permalink( $reservId ) ); ?>?view-type=list"
			class="<?php echo esc_attr( $list ); ?>">
				<i class="stm-carent-rental-ico-list"></i>
			</a>
		</li>
	</ul>
</div>
